//specifies the var function for ball and paddle
var ball,ballImage;
var paddle,paddleImage;

function preload() {
  //loads the image for ball and paddle
  ballImage=loadImage("ball.png");
  paddleImage=loadImage("paddle.png");
}
function setup() {
  //creates the canvas
  createCanvas(400, 300);
  
  //creates the paddle sprite
  paddle=createSprite(390,200,2,2);
  paddle.addImage("paddle",paddleImage);
  paddle.scale=0.73;
  
  //creates the ball sprite
  ball=createSprite(320,200,2,2);
  ball.addImage("ball",ballImage);
  ball.scale=0.48;
  ball.velocityX=9;
}

function draw() {
  
  //creates the background
  background(205,153,0);
  
  //creates the edge sprites
  edges=createEdgeSprites();
  
  //bounces the ball from the edges
  ball.bounceOff(edges[0]);
  ball.bounceOff(edges[2]);
  ball.bounceOff(edges[3]);
  
  //collides the paddle from the edges
  paddle.collide(edges);
  
  //bounces the ball off the paddle giving it random Y         velocity
  ball.bounceOff(paddle,randomVelocity);
  
  //moves the paddle with arrow keys
  if(keyDown(UP_ARROW)){
     paddle.y=paddle.y-20;
  }
  
  if(keyDown(DOWN_ARROW)) {
     paddle.y=paddle.y+20;
  }
  
  //draws the sprites
  drawSprites();
}

function randomVelocity(){
  ball.velocityY=random(-8,8);
}
